﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2021 v5.8.194
	 Created on:   	10/19/2021 3:50 PM
	 Created by:   	ksarens
	 Updated 10/26/2102
	 	fixing error in help information
	 	adding support for offline scenarios
	 Organization: 	
	 Filename:     	MDEHelper.psm1
	===========================================================================
	.DESCRIPTION
		Helper functions for MDE Support solutions
#>

function checkEPPVersion
{
	<#
.SYNOPSIS
	Supportability of Defender EPP components
.DESCRIPTION
    Returns if the provided version of a component (MoCAMP, Engine, Sigs) is lower than the version online and no longer supported
.PARAMETER component
    The component to verify, this can be: MoCAMP|Engine|Sigs
.PARAMETER version
    The version of the component
.PARAMETER xml
    XML document containing the online versions (only needed in offline scenarios). In offline scenarios, the XML document needs to be provided, NOT the path to the xml file
.EXAMPLE
	checkEPPVersion -component MoCAMP -version 4.18.2009.6
        The result of the above example is True as this version is older than N-2 and no longer supported
.NOTES
	If there is no internet connectivity, the method will return $null, in this case provide the XML parameter (see above)
.LINK
#>
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0)]
		[ValidateSet('MoCAMP', 'Engine','Sigs')]
		[string]$component,
		[Parameter(Mandatory = $true, Position = 1)]
		[string]$version,
		[Parameter(Mandatory = $false)]
		[xml]$xml
	)
	
	Begin
	{
		$catch=$false
		if ($null -eq $script:EPP_Versions)
		{
			try {
				if($null -eq $xml)
				{
					$Response = Invoke-WebRequest -URI "https://www.microsoft.com/security/encyclopedia/adlpackages.aspx?action=info" -UseBasicParsing
					[xml]$xml = $Response.Content
				}
			}
			catch {
				$catch=$true
			}
			
			
			$script:EPP_Versions = New-Object System.Management.Automation.PSObject
			Add-Member -InputObject $script:EPP_Versions -NotePropertyName "MoCAMP" -NotePropertyValue $xml.ChildNodes[1].platform
			Add-Member -InputObject $script:EPP_Versions -NotePropertyName "Engine" -NotePropertyValue $xml.ChildNodes[1].engine
			Add-Member -InputObject $script:EPP_Versions -NotePropertyName "Sigs" -NotePropertyValue $xml.ChildNodes[1].signatures.'#text'
			Add-Member -InputObject $script:EPP_Versions -NotePropertyName "Date" -NotePropertyValue $xml.ChildNodes[1].signatures.date
			Add-Member -InputObject $script:EPP_Versions -NotePropertyName "Updated" -NotePropertyValue (Get-Date -Format "MM/dd/yyyy HH:mm")
		}
		if ($version -like "*-*")
		{
			$version = $version.split('-')[0]
		}
	}
	Process
	{
		if($catch)
		{return $null}
		Try
		{
			switch ($component)
			{
				"MoCAMP" {
					
					if ([System.version]$script:EPP_Versions.MoCAMP -gt [System.version]$version)
					{
						$online = @()
						$online += [int]$script:EPP_Versions.MoCAMP.split('.')[0]
						$online += [int]$script:EPP_Versions.MoCAMP.split('.')[1]
						$online += [int]$script:EPP_Versions.MoCAMP.split('.')[2]
						$online += [int]$script:EPP_Versions.MoCAMP.split('.')[3]
						
						$current = @()
						$current += [int]$version.split('.')[0]
						$current += [int]$version.split('.')[1]
						$current += [int]$version.split('.')[2]
						$current += [int]$version.split('.')[3]
						if (($online[2] - $current[2]) -ge 3 -or (($online[2] - $current[2]) -gt 90 -and ($online[2] - $current[2]) -lt 92))
						{
							return $true
						}
						return $false
					}
				}
				"Sigs" {
					if ([System.version]$script:EPP_Versions.Sigs -gt [System.version]$version)
					{
						return $true
					}
				}
				"Engine" {
					if ([System.version]$script:EPP_Versions.Engine -gt [System.version]$version)
					{
						return $true
					}
				}
			}
			return $false
		}
		Catch
		{
			#Write-Log -Message "ERROR $($MyInvocation.MyCommand) [$($var)] - [$_]" -Severity 3
		}
		
	}
	End
	{
		[GC]::Collect()
	}
}
Export-ModuleMember checkEPPVersion
# SIG # Begin signature block
# MIInwwYJKoZIhvcNAQcCoIIntDCCJ7ACAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCA9YhaHHSHxLWs4
# 82HsnJ7/cUuUmBqC+dakbmWaA9IjGKCCDZcwggYVMIID/aADAgECAhMzAAAChGMJ
# YOoqXJUAAAAAAAKEMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjExMDE0MTgzNzA0WhcNMjIxMDEzMTgzNzA0WjCBlDEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjE+MDwGA1UEAxM1TWlj
# cm9zb2Z0IFdpbmRvd3MgRGVmZW5kZXIgQWR2YW5jZWQgVGhyZWF0IFByb3RlY3Rp
# b24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDy2oAT53mmpsbl2qa/
# fagMXVcdwXIF8EOjZsLoXVK69P4Qp7xdN2/dg1upkMqT7qo60LL+4VbjA08T8AHL
# v9F3o2C7EXrmA+ZrRurQvXtTtm0iDliWNUE0mNsGdbnai7om6JpweVh7s6JUOZY3
# qeLc4KTLif7nTOFfyL7CA5tVcta6QRTqCcbedOAQ1jyh5zRd8cGdW/ZmWBC2baTl
# AHzFY4mZ4EaovQlz3xX71KBwUdKwTfUmTiltw7bnIl8Ryr7D0tT2AnohhlJXT8gc
# ndulFy8JoCyKcFew3nV1nWwUf2sXZxpnymJbaLVa19nDqaCk3QQAgrSpnyKCyGc/
# Z5YbAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBggrBgEFBQcDAwYKKwYBBAGCN0wv
# ATAdBgNVHQ4EFgQUZvP/UHnEGqhXN0ZouQ85tadEh0MwRQYDVR0RBD4wPKQ6MDgx
# HjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEWMBQGA1UEBRMNNDUxODk0
# KzQ2ODU5MTAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8E
# TTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9N
# aWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBR
# BggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0
# cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAw
# DQYJKoZIhvcNAQELBQADggIBAGufDQmB0haMlpKGzxUYEJA1DHV/OoZ1VtC9TtOB
# FEZ4By02IWyQqgZAyQqE5xXAgBXngbgj/EB9ASLq8jEp4+M0aV/SPD247gc+uvDw
# +4+FeMSpfNCOfKtGuR5WPZ4WAtL6iGXGev4ka7D3+UogHe34VzIkdTtgwNniTH4T
# FyLDfSepN/zikDOYtMd/pIlAS5jRrnWz17WbxvNII71nHprMr4/iGwv6TMEQ+b3o
# 4voSpZzg40GT9ZkPcT9d/mZicSl00JzwRVnTbE4jxY71P50KasfNpD8WNqnfRJj+
# xoKoIhoHySFU6wJ/woZDB9Kot8tbikII11QtKwPOYLnTR55XnJ7AdEp+yd7IBrTo
# rXUTiZTiFAVxaUQt6u+q1irw2CZcW5/Bp4AKGFTuwxQX/LdtYHNF8sfstECLyk4O
# DxGcmEta/6sFuQsUnl52gso5raywi0RmZD7A/0E420Y1KarzqY4v1r5NODGgLVXW
# woZ++ye1dnNeRnOKt3ZZNq837xbOjbWlHZL1RfkWrN/0HWrbZyV6ph3f/vVyAm/4
# XNX9J6vtO2bxaNWz9yynyJLmcdIjmTIt9pN3mQRED92fWjwh8KE2Ho9kUE3O1VE6
# NUfe2UzHPz3ykr1dXFmVuGQALckgMEdLzBumR3H3US392k5ie6gTV5KyDoTryCDe
# m4X8MIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWlj
# cm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4
# MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBD
# QSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3Y
# bqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUB
# FDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnbo
# MlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT
# +OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuy
# e4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEh
# NSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2
# z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3
# s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78Ic
# V9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E
# 11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5P
# M4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcV
# AQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3
# FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAf
# BgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBL
# hklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNS
# b29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggr
# BgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNS
# b29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsG
# AQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwA
# ZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0G
# CSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDB
# ZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc
# 8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYq
# wooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu
# 5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWI
# UUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXh
# j38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yH
# PgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtI
# EJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4Guzq
# N5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgR
# MiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQ
# zTGCGYIwghl+AgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEC
# EzMAAAKEYwlg6ipclQAAAAAAAoQwDQYJYIZIAWUDBAIBBQCgga4wGQYJKoZIhvcN
# AQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUw
# LwYJKoZIhvcNAQkEMSIEIAu+b3Dxo76vP1XyJFnB7JUB+pPSFO8Gxi1g1xC2p8kh
# MEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8AcwBvAGYAdKEagBhodHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEBBQAEggEAbmXTnTyKjujb
# 9KXc6QLrlstDBk3NstyvwS8HqiE8JbnYC8xLBdSPr8wfxjMBU7afpwiXtQblr1/w
# D7ifXUkbSF+S4cwntXf2fvbWFfiUmp/VEGZV5Ufk7Vvqia15nhPi54Qgv4adnzAL
# zJt6BDX8qOmfqSd+WFq4ajqDEEV7RljWZMSjU9L3b42BM5rAK3ImxNeR3a9X+0h0
# lzML4eE5tlxVoW4PtrpzmDFIPN1LNy+YZ/iu4Qm3+gzIte++epD6ZwhnbrY/Zwgm
# rvQVlSSv9F0OoN6FMQTiPG4qWVZDzE1LAWPp+ZdxN6tT+Ofh8AhTC4M01UpkhQB0
# B4xme9TzAaGCFwwwghcIBgorBgEEAYI3AwMBMYIW+DCCFvQGCSqGSIb3DQEHAqCC
# FuUwghbhAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFVBgsqhkiG9w0BCRABBKCCAUQE
# ggFAMIIBPAIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFlAwQCAQUABCCii+mjRwvg
# 6kQycdw1kNarvl3jpogV7IpccLS9duC8bwIGYtrpCXinGBMyMDIyMDgwMjEzMjQw
# My45NzRaMASAAgH0oIHUpIHRMIHOMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSkwJwYDVQQLEyBNaWNyb3NvZnQgT3BlcmF0aW9ucyBQdWVydG8g
# UmljbzEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046Nzg4MC1FMzkwLTgwMTQxJTAj
# BgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WgghFfMIIHEDCCBPig
# AwIBAgITMwAAAahV8GGpzDAYXAABAAABqDANBgkqhkiG9w0BAQsFADB8MQswCQYD
# VQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEe
# MBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0yMjAzMDIxODUxMjNaFw0yMzA1MTEx
# ODUxMjNaMIHOMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSkw
# JwYDVQQLEyBNaWNyb3NvZnQgT3BlcmF0aW9ucyBQdWVydG8gUmljbzEmMCQGA1UE
# CxMdVGhhbGVzIFRTUyBFU046Nzg4MC1FMzkwLTgwMTQxJTAjBgNVBAMTHE1pY3Jv
# c29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAw
# ggIKAoICAQCj2m3KwC4l1/KY8l6XDDfPSk73JpQIg8OKVPh3o2YYm1HqPx1Mvj/V
# cVoQl+6IHnijyeu+/i3lXT3RuYU7xg4ErqN8PgHJs3F2dkAhlIFEXi1Cm5q69Omw
# dMYb7WcKHpYcbT5IyRbG0xrUrflexOFQoz3WKkGf4jdAK115oGxH1cgsEvodrqKA
# YTOVHGz6ILa+VaYHc21DOP61rqZhVYzwdWrJ9/sL+2gQivI/UFCa6GOMtaZmUn9E
# rhjFmO3JtnL623Zu15XZY6kXR1vgkAAeBKojqoLpn0fmkqaOU++ShtPp7AZI5Rkr
# FNQYteaeKz/PKWZ0qKe9xnpvRljthkS8D9eWBJyrHM8YRmPmfDRGtEMDDIlZZLHT
# 1OyeaivYMQEIzic6iEic4SMEFrRC6oCaB8JKk8Xpt4K2Owewzs0E50KSlqC9B1kf
# SqiL2gu4vV5T7/rnvPY/Xu35geJ4dYbpcxCc1+kTFPUxyTJWzujqz9zTRCiVvI4q
# Qp8vB9X7r0rhX7ge7fviivYNnNjSruRM0rNZyjarZeCjt1M8ly1r00QzuA+T1UDn
# WtLao0vwFqFK8SguWT5ZCxPmD7EuRvhP1QoAmoIT8gWbBzSu8B5Un/9uroS5yqel
# 0QCK6IhGJf+cltJkoY75wET69BiJUptCq6ksAo0eXJFk9bCmhG/MNwIDAQABo4IB
# NjCCATIwHQYDVR0OBBYEFDbH2+Pi+FLrZTYfzMYxpI9JCyLVMB8GA1UdIwQYMBaA
# FJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBSoFCGTmh0dHA6Ly93
# d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUyMFRpbWUtU3Rh
# bXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRgMF4wXAYIKwYBBQUH
# MAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2VydHMvTWljcm9z
# b2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0MAwGA1UdEwEB/wQC
# MAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQELBQADggIBAHE7gktk
# aqpn9pj6+jlMnYZlMfpur6RD7M1oqCV257EW58utpxfWF0yrkjVh9UBX8nP9jd2E
# xKeIRPGLYWCoAzPx1IVERF91k8BrHmLrg3ksVkSVgqKwBxdZMEMyCoK1HNxvrlcA
# JhvxCNRC0RMQOH7cdBIa3+fWiZuzp4J9JU0koilHrhgPjMuqAov1fBE8c/nm5b0A
# DWpbSYBn6abll2E+I4rEChE76CYwb+cfgQNKBBbu4BmnjA5GY5zub3X+h3ip3iC7
# PWb8CFpIGEItmXqM28YJRuWMBMaIsXpMa0Uw2cDKJCGMV5nHLHENMV5ofiN76O4V
# fWTCk2vT2s+Z3uHHPDncNU/utuJgdFmlvRwBNYaIwegm37p3bVf48MZnSodeaZSV
# 5zdcjOzi/duB6gIiYrB2p6ThCeFJvW94RVFxNrhCS/WmLiIJLFWCKtT9va0eF+5c
# 97hCR+gjpKBOvlHGrjeiWBYITfSPCUQVgIR1+BkB5Z4LHX7Viy4g2TMp5YEQmc5G
# CNuDfXMfg9+u2MHJajWOgmbgIM8MtdrkWBUGrGB2CtYac8k7biPwNgfHBvhzOl9Y
# 39nfbgEcB+voS5D7bd/+TQZS16TpeYmckZQYu4g15FjWt47hnywCdyEg8jYe8rvh
# +MkGMkbPzFawpFlCbPRIryyrDSdgfyIza0rWMIIHcTCCBVmgAwIBAgITMwAAABXF
# 52ueAptJmQAAAAAAFTANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2Vy
# dGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMjEwOTMwMTgyMjI1WhcNMzAwOTMw
# MTgzMjI1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYw
# JAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCAiIwDQYJKoZI
# hvcNAQEBBQADggIPADCCAgoCggIBAOThpkzntHIhC3miy9ckeb0O1YLT/e6cBwfS
# qWxOdcjKNVf2AX9sSuDivbk+F2Az/1xPx2b3lVNxWuJ+Slr+uDZnhUYjDLWNE893
# MsAQGOhgfWpSg0S3po5GawcU88V29YZQ3MFEyHFcUTE3oAo4bo3t1w/YJlN8OWEC
# esSq/XJprx2rrPY2vjUmZNqYO7oaezOtgFt+jBAcnVL+tuhiJdxqD89d9P6OU8/W
# 7IVWTe/dvI2k45GPsjksUZzpcGkNyjYtcI4xyDUoveO0hyTD4MmPfrVUj9z6BVWY
# bWg7mka97aSueik3rMvrg0XnRm7KMtXAhjBcTyziYrLNueKNiOSWrAFKu75xqRdb
# Z2De+JKRHh09/SDPc31BmkZ1zcRfNN0Sidb9pSB9fvzZnkXftnIv231fgLrbqn42
# 7DZM9ituqBJR6L8FA6PRc6ZNN3SUHDSCD/AQ8rdHGO2n6Jl8P0zbr17C89XYcz1D
# TsEzOUyOArxCaC4Q6oRRRuLRvWoYWmEBc8pnol7XKHYC4jMYctenIPDC+hIK12Nv
# DMk2ZItboKaDIV1fMHSRlJTYuVD5C4lh8zYGNRiER9vcG9H9stQcxWv2XFJRXRLb
# JbqvUAV6bMURHXLvjflSxIUXk8A8FdsaN8cIFRg/eKtFtvUeh17aj54WcmnGrnu3
# tz5q4i6tAgMBAAGjggHdMIIB2TASBgkrBgEEAYI3FQEEBQIDAQABMCMGCSsGAQQB
# gjcVAgQWBBQqp1L+ZMSavoKRPEY1Kc8Q/y8E7jAdBgNVHQ4EFgQUn6cVXQBeYl2D
# 9OXSZacbUzUZ6XIwXAYDVR0gBFUwUzBRBgwrBgEEAYI3TIN9AQEwQTA/BggrBgEF
# BQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9z
# aXRvcnkuaHRtMBMGA1UdJQQMMAoGCCsGAQUFBwMIMBkGCSsGAQQBgjcUAgQMHgoA
# UwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQY
# MBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6
# Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1
# dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0
# dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIw
# MTAtMDYtMjMuY3J0MA0GCSqGSIb3DQEBCwUAA4ICAQCdVX38Kq3hLB9nATEkW+Ge
# ckv8qW/qXBS2Pk5HZHixBpOXPTEztTnXwnE2P9pkbHzQdTltuw8x5MKP+2zRoZQY
# Iu7pZmc6U03dmLq2HnjYNi6cqYJWAAOwBb6J6Gngugnue99qb74py27YP0h1AdkY
# 3m2CDPVtI1TkeFN1JFe53Z/zjj3G82jfZfakVqr3lbYoVSfQJL1AoL8ZthISEV09
# J+BAljis9/kpicO8F7BUhUKz/AyeixmJ5/ALaoHCgRlCGVJ1ijbCHcNhcy4sa3tu
# PywJeBTpkbKpW99Jo3QMvOyRgNI95ko+ZjtPu4b6MhrZlvSP9pEB9s7GdP32THJv
# EKt1MMU0sHrYUP4KWN1APMdUbZ1jdEgssU5HLcEUBHG/ZPkkvnNtyo4JvbMBV0lU
# ZNlz138eW0QBjloZkWsNn6Qo3GcZKCS6OEuabvshVGtqRRFHqfG3rsjoiV5PndLQ
# THa1V1QJsWkBRH58oWFsc/4Ku+xBZj1p/cvBQUl+fpO+y/g75LcVv7TOPqUxUYS8
# vwLBgqJ7Fx0ViY1w/ue10CgaiQuPNtq6TPmb/wrpNPgkNWcr4A245oyZ1uEi6vAn
# Qj0llOZ0dFtq0Z4+7X6gMTN9vMvpe784cETRkPHIqzqKOghif9lwY1NNje6CbaUF
# EMFxBmoQtB1VM1izoXBm8qGCAtIwggI7AgEBMIH8oYHUpIHRMIHOMQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSkwJwYDVQQLEyBNaWNyb3NvZnQg
# T3BlcmF0aW9ucyBQdWVydG8gUmljbzEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046
# Nzg4MC1FMzkwLTgwMTQxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNl
# cnZpY2WiIwoBATAHBgUrDgMCGgMVAGy6/MSfQQeKy+GIOfF9S2eYkHcsoIGDMIGA
# pH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwDQYJKoZIhvcNAQEFBQAC
# BQDmkz7UMCIYDzIwMjIwODAyMTAxMjM2WhgPMjAyMjA4MDMxMDEyMzZaMHcwPQYK
# KwYBBAGEWQoEATEvMC0wCgIFAOaTPtQCAQAwCgIBAAICArUCAf8wBwIBAAICEmgw
# CgIFAOaUkFQCAQAwNgYKKwYBBAGEWQoEAjEoMCYwDAYKKwYBBAGEWQoDAqAKMAgC
# AQACAwehIKEKMAgCAQACAwGGoDANBgkqhkiG9w0BAQUFAAOBgQAlqmv3NSS2lN0o
# NEdAmETIc/TW+8/+hl4siA05Ba1ZP/vbN6uaw3ipp0cqxNPOUeMx8Q3nWepIS8j8
# iE0vSa7F4XlzKkF1jO3vJAt/l6ClMukRRlzL0I8j3OCsd7E+/n5OP/srhKJTWgNi
# EUcFvRI9W0DTP635tN0inzau6mmpDjGCBA0wggQJAgEBMIGTMHwxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBU
# aW1lLVN0YW1wIFBDQSAyMDEwAhMzAAABqFXwYanMMBhcAAEAAAGoMA0GCWCGSAFl
# AwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQwLwYJKoZIhvcN
# AQkEMSIEIDx8pCsy4tPLUJCRJfHyjbejMNvUGH5KKCysdwCxGqHNMIH6BgsqhkiG
# 9w0BCRACLzGB6jCB5zCB5DCBvQQgdP7LHQDLB8JzcIXxQVz5RZ0b1oR6kl/WC1MQ
# Q5dcZaYwgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAA
# AahV8GGpzDAYXAABAAABqDAiBCAFZjzHarZ/hRpE98LZckNAXYw2WTP8uk3eOFOO
# 6/8h0TANBgkqhkiG9w0BAQsFAASCAgB5xZ9Qhp7NO9+E4EiLXwovJN141Rrl6Xuo
# XhjwuLqj6JHlNBbVMDucByncnT5nD3uLfCrWivSDXQVLs3grkdw2lv2rFwoh2fis
# hYz168HCt5Kz/Zay1EkcABtDxGeSeT7FsnrDRH1hFO90V+azgJBM975z3ITHxD2Y
# GmFBDNTWLjRALt6t0YQzO1MQH92GOG8SZ0AQr6v5TzSTATdRkLBY7+twg7ZqHtHu
# 39RWxT75dBfWWE026ln+pJnelHoCfiz0Dravot/vic7fah5cVDr6cwMpQFKiHWAa
# BgBzdZD1qdiTvtwlFn7yFOLqKw5hnl3ib0lxfsKZItIXZNBwE+Ctz8iL5W3oVOi2
# XLqlCv0dtpdIT3LJq0sQnesaZuhm4BUrn9h9o5uMLrvXbBswAaIqbZMhBEwefgYh
# bNLFz/iMRsXRQTTg2QwHZJg6CUpksWNBqHi7X3GCv3E8ZafGIkkEpjaJGkUs1ZgK
# jBHVVclxfz7J7UaJYytSllgJIIlE3y5LUrfRNRGDQcL/kOAZc1DGdQrWYG2IIaiL
# POrNaklVJcRRVheQN99tm1TtQbJ1/WiV+PG6NQ9UKdDo7/I7SbK/xxMGqFy0D5U1
# AyJCXXCfUbLp+WHz8C+hxUxDqsovCLysLz9ZQQ5WNE/vwt7Fkyn47T/WAlQV1NHC
# cwZCXHEB/A==
# SIG # End signature block
